"""QUESTION 1"""

"""Define a reverse function using the
combine function. Assume that n cannot contain
any digits that are 0"""

def combine(left, right):
	factor = 1
	n = right
	while n: # while n != 0
		n = n // 10
		factor = factor * 10
	return left * factor + right

def reverse(n):
	"""Use the combine function to define reverse recursively
	*** For the sake of not dealing with annoying edge cases,
	assume that n does not contain any digits that are 0 ***	
	>>> reverse(523)
	325
	>>> reverse(4)
	4
	>>> reverse(123456)
	654321
	"""
	





square = lambda x: x * x
double = lambda x: 2 * x

"""QUESTION 2"""

"""Define a higher order function memory that acts
as shown in the doctests (Fill in the blanks) """

def memory(x, f):
	"""Returns a higher order function that prints its memories.
	>>> f = memory(3, lambda x: x)
	>>> f = f(square)
	3
	>>> f = f(double)
	9
	>>> f = f(print)
	6
	>>> f = f(square)
	3
	None
	"""
	def g(h):
		print(___________)
		return ____________________
	return g

	

"""QUESTION 3"""

"""Implement the make_change function which takes
in change n and finds the minimum number of coins
needed to make change for n. The currency involved
is the following: 1 cent, 3 cent, and 4 cent coins"""

def make_change(n):
	"""Function that finds the minimum number
	of coins necessary to make change for 
	a partcular n
	We have some special coins - 1 cent, 3 cent, and 4 cent
	n - non-negative integer
	
	>>> make_change(2)
	2
	>>> make_change(3) 
	1
	>>> make_change(5)
	2
	>>> make_change(6) # tricky! Not 4 + 1 + 1 but 3 + 3
	2
	>>> make_change(7)
	2
	>>> make_change(21) # 4 cent * 5 + 1 cent
	6
	>>> make_change(30) # 4 cent * 6 + 3 cent * 2
	8
	"""
	
