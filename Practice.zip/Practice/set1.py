"""QUESTION 1"""

"""Define a function that computes the
factorial of a number"""

def factorial(n):
	""" Return 1 * 2 * 3 * .... * n
	>>> factorial(0)
	1
	>>> factorial(1)
	1
	>>> factorial(3)
	6
	>>> factorial(6)
	720
	>>> factorial(8)
	40320
	"""



"""QUESTION 2"""

"""Define a function that calculates nth fibonacci
number in the fibonacci sequence"""

def fib(n):
	"""Calculates the nth fibonacci numbers
	fibonacci sequence - 0, 1, 1, 2, 3, 5, 8, 13, 21, 34
	>>> fib(1)
	0
	>>> fib(2)
	1
	>>> fib(3)
	1
	>>> fib(6)
	5
	>>> fib(8)
	13
	>>> fib(10)
	34
	"""

"""QUESTION 3"""

"""Define a function that sums the natural numbers
from 1 to n"""

def sum_naturals(n):
	"""Computes 1 + 2 + 3 + ... + n
	>>> sum_naturals(0)
	0
	>>> sum_naturals(1)
	1
	>>> sum_naturals(3)
	6
	>>> sum_naturals(10)
	55
	>>> sum_naturals(100)
	5050
	"""

"""QUESTION 4"""

"""Can you define the same function in
one return statement?"""

def b_sum_naturals(n):
	"""Computes 1 + 2 + 3 + ... + n
	Can only use a single return statement
	>>> b_sum_naturals(3)
	6
	>>> b_sum_naturals(10)
	55
	>>> b_sum_naturals(100)
	5050
	"""
	
"""QUESTION 5"""

"""Defines a function that determines
whether a number is prime or not"""


def is_prime(n):
	"""Returns true if a number is prime 
	and false otherwise	
	>>> is_prime(2)
	True
	>>> is_prime(3)
	True
	>>> is_prime(97)
	True
	>>> is_prime(24)
	False
	>>> is_prime(169)
	False
	"""
	
"""QUESTION 6"""

"""Define a combine function that puts together two
numbers. Look at doctests for clarification"""


def combine(left, right):
	""" Combines the digits on the left number
	with the digits on the right number	
	>>> combine(123, 456)
	123456
	>>> combine(112, 20)
	11220
	>>> combine(10, 3)
	103
	""" 
	
"""QUESTION 7"""

"""Define a function that reverses a number n"""

def reverse(n):
	"""Reverses the number n	
	>>> reverse(123)
	321
	>>> reverse(34)
	43
	>>> reverse(20)
	2
	>>> reverse(23456)
	65432
	"""
"""QUESTION 8 (From Past CS61A Exam)"""

"""Implement the longest_increasing_suffix function, which returns the longest suffix (end) of a
positive integer that consists of strictly increasing digits. (Only have to fill in blanks)"""


def longest_increasing_suffix(n):
	"""
	Return the longest increasing suffix of a positive integer n.	
	>>> longest_increasing_suffix(63134)
	134
	>>> longest_increasing_suffix(233)
	3
	>>> longest_increasing_suffix(5689)
	5689
	>>> longest_increasing_suffix(568901)
	1
	"""
	m, suffix, k = 10 , 0, 1
	while n:
		_______________ , last = n // 10, n % 10
		if _______________________:
			m, suffix, k = _____________, ___________________________,  10 * k			
		else:
			return suffix
	return suffix

