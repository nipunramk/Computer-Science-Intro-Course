"""PRACTICE PROBLEMS: Runtime, Linked Lists, Iterators, and Trees
Reference Video 22 for walkthrough of solutions"""

"""QUESTION 1"""

"""Find the runtime of foo(evenify(n))"""

def evenify(n):
	if n % 2 == 1:
		return n + 1
	return n

def foo(n):	
	if n < 0:
		return 2
	elif n % 2 == 0:
		return foo(n - 1) + foo(n - 2)
	else:
		return 1 + foo(n - 2)

"""QUESTION 2"""

"""Define an iterator for a linked list.
HINT - you might find it useful to define a new 
class that defines the __next__ method similar
to the RangeIterator example we did ealier"""
class Link:
	
	empty = ()
	def __init__(self, first, rest=empty):
		assert rest is Link.empty or isinstance(rest, Link)
		self.first = first
		self.rest = rest
	def __len__(self):
		return 1 + len(self.rest)
	def __getitem__(self, i):
		if i == 0:
			return self.first
		else:
			return self.rest[i - 1]
	def __repr__(self):
		rest_str = ''
		if self.rest is Link.empty:
			rest_str = ''
		else:
			rest_str = ', ' + repr(self.rest)
		return 'Link({0}{1})'.format(self.first, rest_str)


"""QUESTION 3"""

"""Define the function delete so that
it deletes the first instance of a particular
elem in the linked list. If the element is not
in the linked list, the function should not
delete anything from the linked list. This is
a non-destructive function"""

def delete(link, elem):
	"""Deletes the first instance of a
	particular element from a linked list
	>>> link1 = Link(1, Link(2, Link(3)))
	>>> delete(link1, 3)
	Link(1, Link(2))
	>>> link2 = Link(1)
	>>> delete(link2, 3) # elem not in linked list 
	Link(1)
	>>> link3 = Link(2, Link(4, Link(6, Link(8, Link(9)))))
	>>> delete(link3, 6)
	Link(2, Link(4, Link(8, Link(9))))
	"""

"""QUESTION 4"""

"""Define the function reverse so that it
returnes the reversed version of the linked
list passed in"""
	
def reverse(link):
	"""Returns a reversed version of the linked list
	>>> link1 = Link(1, Link(2, Link(3)))
	>>> reverse(link1)
	Link(3, Link(2, Link(1)))
	>>> link2 = Link(1)
	>>> reverse(link2)
	Link(1)
	>>> reverse(Link.empty)
	()
	>>> link3 = Link(2, Link(4, Link(6, Link(8, Link(9)))))
	>>> reverse(link3)
	Link(9, Link(8, Link(6, Link(4, Link(2)))))
	"""


"""QUESTION 5"""

"""This question is particularly challenging. Define a
function that deterimines whether a linked list has 
a cycle. A cycle occurs in a linked list when the rest
of a linked list points to itself or a previous part of
the linked list""" 	

def has_cycle(link):
	"""
	Determines if a link list has a cycle
	>>> link1 = Link(1, Link(2, Link(3)))
	>>> has_cycle(link1)
	False
	>>> link1.rest.rest = link1 # Creates a cycle
	>>> has_cycle(link1)
	True
	>>> link2 = Link(2, Link(4, Link(6, Link(8, Link(9)))))
	>>> has_cycle(link2)
	False
	>>> link2.rest.rest.rest = link2.rest # Creates a cycle
	>>> has_cycle(link2)
	True
	"""

	

	
class Tree:
	def __init__(self, entry, branches=[]):
		self.entry = entry
		for branch in branches:
			assert isinstance(branch, Tree)
		self.branches = branches
	def __repr__(self):
		if not self.branches:
			branches_str = ''
		else:
			branches_str = ', ' + repr(self.branches)
		return 'Tree({0}{1})'.format(self.entry, branches_str)

def is_leaf(t):
	"""Returns true if tree t is a leaf and
	false otherwise
	>>> t1 = Tree(1, [Tree(2), Tree(3)])
	>>> is_leaf(t1)
	False
	>>> is_leaf(t1.branches[0])
	True
	"""
	return len(t.branches) == 0

"""QUESTION 6"""
"""Write a function that determines if a tree t 
contains the element elem"""

def contains(elem, t):
	"""
	>>> t1 = Tree(1, [Tree(2), Tree(3)])
	>>> contains(4, t1)
	False
	>>> contains(2, t1)
	True
	>>> t2 = Tree(1, [Tree(2, [Tree(3), Tree(4)]), Tree(5), Tree(6)])
	>>> contains(4, t2)
	True
	"""


"""QUESTION 7"""

"""Define a function path_counter such that it counts the
number of paths in the tree from root to leaf such that 
the sum of the path is greater than or equal to n. The one
function is defined below to help you with the definition
of path_counter"""

	
def one(b):
	"""Returns 1 if b is a true value, 0 if false value"""
	if b:
		return 1
	else:
		return 0


def path_counter(t, n):
	"""Returns the number of paths in tree t 
	that have a sum larger than or equal to n
	*Hint use the one function to your advantage
	>>> t = Tree(1, [Tree(2), Tree(3, [Tree(4), Tree(5)])])
	>>> path_counter(t, 3)
	3
	>>> path_counter(t, 6)
	2
	>>> path_counter(t, 9)
	1
	"""

	
