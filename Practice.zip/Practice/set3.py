"""QUESTION 1"""

"""Define a function sort that sorts a list
from least to greatest"""

def sort(lst):
	"""Sort the given lst from least to greatest		
	>>> sort([13, 4, 7, 10, 2, 5, 2, 1])
	[1, 2, 2, 4, 5, 7, 10, 13]
	"""

"""QUESTION 2"""

"""Implement the function deep_map which takes
a single argument function f and maps it over a 
list. The list can be nested or non-nested"""	

def deep_map(f, lst):
	"""Map the function f over a list that
	(potentially) could be nested	
	length of list 0 --> return lst
	lst = [[1, 2], 3, [4]]
	lst[0] - [1, 2] <-- new lst
	[f(lst[0])] + deep_map(f, lst[1:]) --> [1, 4]
	>>> deep_map(lambda x: x + 1, [1, 2, 3, 4])
	[2, 3, 4, 5]
	>>> square = lambda x: x * x
	>>> deep_map(square, [[1, 2], 3, [4]])
	[[1, 4], 9, [16]]
	>>> deep_map(square, [[[3], 4, [5, 1]], 6])
	[[[9], 16, [25, 1]], 36]
	"""

"""QUESTION 3"""

"""Define the function is_anagram that returns true if string s1
and s2 are anagrams of each other"""

def is_anagram(s1, s2):
	"""Returns True is string s1 and string s2 are 
	anagrams of each other (note s1 and s2 don't need to be valid words)
	Anagram - word that can be formed by rearranging the letters of another
	>>> is_anagram('cinema', 'iceman')
	True
	>>> is_anagram('listen', 'silent')
	True
	>>> is_anagram('torchwood', 'doctorwho')
	True
	>>> is_anagram('grades', 'intelligent')
	False
	>>> is_anagram('smart', 'taser')
	False
	"""

"""QUESTION 4"""

"""Implement the same is_anagram function,
except using a single return statment
Hint: you might find the string method .join() useful
"""

def clever_is_anagram(s1, s2):
	"""Returns True is string s1 and string s2 are 
	anagrams of each other (note s1 and s2 don't need to be valid words)
	Anagram - word that can be formed by rearranging the letters of another
	>>> clever_is_anagram('cinema', 'iceman')
	True
	>>> clever_is_anagram('listen', 'silent')
	True
	>>> clever_is_anagram('torchwood', 'doctorwho')
	True
	>>> clever_is_anagram('grades', 'intelligent')
	False
	>>> clever_is_anagram('smart', 'taser')
	False
	"""
	






	




